﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5c_sharp
{
    interface IHuman
    {
        string Name
        {
            get;
            set;
        }

        string Sex
        {
            get;
            set;
        }
    }
}
