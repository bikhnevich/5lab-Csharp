﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5c_sharp
{
    class Engineer : IStaff, IHuman
    {
        string name;
        string sex;
        string position;

        public Engineer()
        {

        }

        public Engineer(string name, string sex,string position)
        {
            Name = name;
            Sex = sex;
            Position = position;
        }

        public string Name
        {
            set
            {
                name = value;
            }

            get
            {
                return name;
            }
        }
        public string Sex
        {
            set
            {
                sex = value;
            }

            get
            {
                return sex;
            }
        }

        public string Position
        {
            set
            {
                position = value;
            }

            get
            {
                return position;
            }
        }

        public void Duty()
        {
            Console.WriteLine("Основным содержанием деятельности инженера является разработка новых и/или оптимизация существующих инженерных решений.");
        }
    }
}
