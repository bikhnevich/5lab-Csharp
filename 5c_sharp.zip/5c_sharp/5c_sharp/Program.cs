﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5c_sharp
{
    class Program
    {
        delegate Worker InputData(Worker worker);

        private static Worker Input(Worker worker)
        {
            Console.WriteLine("Имя работника :");
            worker.Name = Console.ReadLine();
            Console.WriteLine("Пол работника :");
            worker.Sex = Console.ReadLine();
            Console.WriteLine("Должность :");
            worker.Position = Console.ReadLine();
           
            return worker;
        }

        static void Main(string[] args)
        {

            Administration administration = new Administration();
            administration.Duty();


            Worker worker = new Worker();
            InputData inp;
            inp = Input;
            inp(worker);

        }
    }
}
