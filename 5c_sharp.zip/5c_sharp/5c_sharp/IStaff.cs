﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5c_sharp
{
    interface IStaff
    {
        void Duty();

        string Position
        {
            get;
            set;
        }
    }
}
