﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5c_sharp
{
    class Administration : IAdmin
    {

        string name;

        public Administration()
        {

        }

        public Administration(string name)
        {
            Name = name;
        }

        public string Name
        {
            set
            {
                name = value;
            }

            get
            {
                return name;
            }
        }


        public void Duty()
        {
            Console.WriteLine("Администрация- руководство, аппарат управления фирмы, предприятия, организации, круг лиц, уполномоченных осуществлять оперативное управление, выступать в качестве юридического лица, официально представлять организацию.");
        }
    }
}
